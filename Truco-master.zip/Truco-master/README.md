# Truco
TP final algo 3

Grupo 2 nico:

	Ezequiel Martin Ortega Mateo 
	
	Micaela Lean Cole 
	
	Marcos Pozzo 
	
Informe:

	https://docs.google.com/document/d/1YW0JrZrHsyU-FF154s8s035MsTNscq002922uvpTz64/edit
	
Comando para ejecutar por consola con ant:

	ejecutar.aplicacion