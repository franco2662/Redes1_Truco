package fiuba.algo3.tpfinal.modelo;

public enum Equipo {
	EQUIPO1, EQUIPO2
}
