package fiuba.algo3.tpfinal.modelo;

public enum Resultado {
	GANADOR1, GANADOR2, EMPATE
}
