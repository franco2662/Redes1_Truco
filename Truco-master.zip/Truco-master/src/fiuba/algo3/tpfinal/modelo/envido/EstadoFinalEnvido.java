package fiuba.algo3.tpfinal.modelo.envido;

public class EstadoFinalEnvido extends EstadoEnvido {

	public EstadoFinalEnvido(EstadoEnvido estadoAnteriorEnvido) {
		super(estadoAnteriorEnvido);
		this.puntosDeEstado = 0;
	}

}
