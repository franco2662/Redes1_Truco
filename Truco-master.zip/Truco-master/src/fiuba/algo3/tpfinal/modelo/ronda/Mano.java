package fiuba.algo3.tpfinal.modelo.ronda;

public enum Mano {
	INICIAL, PRIMERA, SEGUNDA, TERCERA
}
