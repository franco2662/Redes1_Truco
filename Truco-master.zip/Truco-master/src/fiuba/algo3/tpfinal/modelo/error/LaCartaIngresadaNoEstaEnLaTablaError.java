package fiuba.algo3.tpfinal.modelo.error;

public class LaCartaIngresadaNoEstaEnLaTablaError extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
