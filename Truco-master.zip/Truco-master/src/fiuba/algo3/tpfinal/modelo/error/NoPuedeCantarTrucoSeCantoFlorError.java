package fiuba.algo3.tpfinal.modelo.error;

public class NoPuedeCantarTrucoSeCantoFlorError extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
