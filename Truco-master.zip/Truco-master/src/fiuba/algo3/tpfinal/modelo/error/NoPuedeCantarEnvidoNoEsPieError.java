package fiuba.algo3.tpfinal.modelo.error;

public class NoPuedeCantarEnvidoNoEsPieError extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
