package fiuba.algo3.tpfinal.modelo;

public interface CartaParaEnvidoYFlor {
	public int obtenerValorParaEnvidoYFlor();
}
