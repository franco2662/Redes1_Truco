package fiuba.algo3.tpfinal.modelo;

public enum Palo {
	ORO, BASTO, COPA, ESPADA
}